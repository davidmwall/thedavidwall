import Database from "better-sqlite3";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { config } from "../config.js";

mkdirSync(dirname(config.DB_PATH), { recursive: true });

export const db = new Database(config.DB_PATH);
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS webhook_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    received_at TEXT NOT NULL DEFAULT (datetime('now')),
    event_type TEXT,
    contact_id TEXT,
    conversation_id TEXT,
    payload_json TEXT NOT NULL,
    processed INTEGER NOT NULL DEFAULT 0,
    error TEXT
  );

  CREATE INDEX IF NOT EXISTS idx_webhook_events_contact_id
    ON webhook_events (contact_id);

  CREATE TABLE IF NOT EXISTS pending_drafts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    webhook_event_id INTEGER,
    contact_id TEXT NOT NULL,
    conversation_id TEXT NOT NULL,
    category TEXT NOT NULL,
    reasoning TEXT,
    draft_text TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending_approval',
    approver_reply TEXT,
    sent_at TEXT
  );

  CREATE INDEX IF NOT EXISTS idx_pending_drafts_status
    ON pending_drafts (status);

  CREATE TABLE IF NOT EXISTS bot_sent_messages (
    ghl_message_id TEXT PRIMARY KEY,
    contact_id TEXT NOT NULL,
    sent_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

export type WebhookEventRow = {
  id: number;
  received_at: string;
  event_type: string | null;
  contact_id: string | null;
  conversation_id: string | null;
  payload_json: string;
  processed: number;
  error: string | null;
};

export function insertWebhookEvent(input: {
  eventType: string | null;
  contactId: string | null;
  conversationId: string | null;
  payload: unknown;
}): number {
  const stmt = db.prepare(`
    INSERT INTO webhook_events (event_type, contact_id, conversation_id, payload_json)
    VALUES (@eventType, @contactId, @conversationId, @payloadJson)
  `);
  const result = stmt.run({
    eventType: input.eventType,
    contactId: input.contactId,
    conversationId: input.conversationId,
    payloadJson: JSON.stringify(input.payload),
  });
  return Number(result.lastInsertRowid);
}

export function markWebhookEventProcessed(id: number, error?: string): void {
  db.prepare(
    `UPDATE webhook_events SET processed = 1, error = @error WHERE id = @id`
  ).run({ id, error: error ?? null });
}

export type PendingDraftStatus =
  | "pending_approval"
  | "auto_sent"
  | "approved_sent"
  | "edited_sent"
  | "rejected";

export type PendingDraftRow = {
  id: number;
  created_at: string;
  webhook_event_id: number | null;
  contact_id: string;
  conversation_id: string;
  category: string;
  reasoning: string | null;
  draft_text: string;
  status: PendingDraftStatus;
  approver_reply: string | null;
  sent_at: string | null;
};

export function insertPendingDraft(input: {
  webhookEventId: number | null;
  contactId: string;
  conversationId: string;
  category: string;
  reasoning: string;
  draftText: string;
  status: PendingDraftStatus;
}): number {
  const result = db
    .prepare(
      `INSERT INTO pending_drafts
        (webhook_event_id, contact_id, conversation_id, category, reasoning, draft_text, status, sent_at)
       VALUES
        (@webhookEventId, @contactId, @conversationId, @category, @reasoning, @draftText, @status,
         CASE WHEN @status = 'auto_sent' THEN datetime('now') ELSE NULL END)`
    )
    .run(input);
  return Number(result.lastInsertRowid);
}

export function getPendingDraft(id: number): PendingDraftRow | undefined {
  return db
    .prepare(`SELECT * FROM pending_drafts WHERE id = ?`)
    .get(id) as PendingDraftRow | undefined;
}

export function getMostRecentPendingApproval(): PendingDraftRow | undefined {
  return db
    .prepare(
      `SELECT * FROM pending_drafts WHERE status = 'pending_approval' ORDER BY id DESC LIMIT 1`
    )
    .get() as PendingDraftRow | undefined;
}

/**
 * Records the GHL message id of a text the bot itself sent to a lead, so a
 * later inbound event can tell "the bot's own message" apart from one sent
 * by a human (or another GHL workflow) that jumped into the same thread.
 * `ghlMessageId` may be undefined if GHL's send response didn't include one
 * (older/changed API shape) — silently skipped, since failing to record a
 * bot-sent message only makes the pause check more cautious, never less.
 */
export function recordBotSentMessage(ghlMessageId: string | undefined, contactId: string): void {
  if (!ghlMessageId) {
    console.warn(
      `[db] no message id returned for a bot-sent SMS to contact ${contactId}; pause detection may be overly cautious for this contact`
    );
    return;
  }
  db.prepare(
    `INSERT OR IGNORE INTO bot_sent_messages (ghl_message_id, contact_id) VALUES (?, ?)`
  ).run(ghlMessageId, contactId);
}

export function isBotSentMessage(ghlMessageId: string): boolean {
  const row = db
    .prepare(`SELECT 1 FROM bot_sent_messages WHERE ghl_message_id = ?`)
    .get(ghlMessageId);
  return row !== undefined;
}

export function resolvePendingDraft(
  id: number,
  status: Exclude<PendingDraftStatus, "pending_approval" | "auto_sent">,
  approverReply?: string
): void {
  db.prepare(
    `UPDATE pending_drafts
     SET status = @status,
         approver_reply = @approverReply,
         sent_at = CASE WHEN @status IN ('approved_sent', 'edited_sent') THEN datetime('now') ELSE sent_at END
     WHERE id = @id`
  ).run({ id, status, approverReply: approverReply ?? null });
}
