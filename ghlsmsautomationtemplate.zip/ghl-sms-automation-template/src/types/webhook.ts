import { z } from "zod";

/**
 * This is NOT a shape we control — it's GHL's built-in "standard data" that
 * every Webhook action sends automatically for a Customer Replied trigger
 * (contact fields flattened at root, plus nested `message`/`location`).
 * Custom key-value pairs added in the workflow builder land under a
 * `customData` key instead of the root, which is why we don't rely on those.
 * Unknown extra fields are kept via passthrough so nothing is silently dropped.
 */
export const ghlWebhookPayloadSchema = z
  .object({
    contact_id: z.string().optional(),
    phone: z.string().optional(),
    message: z
      .object({
        body: z.string().optional(),
      })
      .optional(),
    location: z
      .object({
        id: z.string().optional(),
      })
      .optional(),
  })
  .passthrough();

export type GhlWebhookPayload = z.infer<typeof ghlWebhookPayloadSchema>;
