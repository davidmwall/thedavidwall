import express from "express";
import { config } from "./config.js";
import { ghlApprovalRouter } from "./routes/ghlApproval.js";
import { internalRouter } from "./routes/internal.js";
import { vcardRouter } from "./routes/vcard.js";
import { webhookRouter } from "./routes/webhook.js";
import { scheduleDailyReview } from "./schedule/dailyReview.js";

const app = express();
app.use(express.json());

app.get("/healthz", (_req, res) => {
  res.status(200).json({ ok: true });
});

app.use("/webhooks", webhookRouter);
app.use("/webhooks", ghlApprovalRouter);
app.use("/internal", internalRouter);
app.use(vcardRouter);

app.listen(config.PORT, () => {
  console.log(`GHL SMS automation listening on :${config.PORT}`);
});

scheduleDailyReview();
