import "dotenv/config";
import { z } from "zod";

const envSchema = z.object({
  PORT: z.coerce.number().default(3000),

  // GHL Private Integration (Settings > Private Integrations in the target sub-account)
  GHL_LOCATION_ID: z.string().min(1, "GHL_LOCATION_ID is required"),
  GHL_PRIVATE_INTEGRATION_TOKEN: z
    .string()
    .min(1, "GHL_PRIVATE_INTEGRATION_TOKEN is required"),
  GHL_API_BASE_URL: z.string().url().default("https://services.leadconnectorhq.com"),
  GHL_API_VERSION: z.string().default("2021-07-28"),

  // Shared secret we require GHL's outbound webhook to send back to us
  GHL_WEBHOOK_SECRET: z.string().min(1, "GHL_WEBHOOK_SECRET is required"),

  DB_PATH: z.string().default("./data/app.sqlite"),

  ANTHROPIC_API_KEY: z.string().min(1, "ANTHROPIC_API_KEY is required"),
  CLAUDE_MODEL: z.string().default("claude-sonnet-5"),

  // The name Claude signs drafts with — never let it guess or placeholder this.
  AGENT_NAME: z.string().min(1, "AGENT_NAME is required"),

  // The GHL contact record for you (the business owner/approver). Held
  // drafts are texted to this contact via GHL's own send-SMS API, and only
  // replies from this contact are accepted as approve/edit/reject commands.
  GHL_OWNER_CONTACT_ID: z.string().min(1, "GHL_OWNER_CONTACT_ID is required"),

  // The business's own IANA timezone, used to compute the correct
  // call-time offset when telling the owner what to book on their calendar.
  BUSINESS_TIMEZONE: z.string().default("America/Phoenix"),

  // Not currently used (the bot notifies instead of auto-booking — see
  // README "Known limitation"), kept optional in case direct booking via
  // ghlClient.createAppointment gets re-enabled later.
  GHL_CALENDAR_ID: z.string().optional(),

  // Gates POST /internal/run-backlog-resend. Optional so normal boot never
  // fails without it, but the route itself refuses to run unless it's set
  // and matches the provided header - fails closed, not open.
  INTERNAL_JOB_SECRET: z.string().optional(),
});

const parsed = envSchema.safeParse(process.env);

if (!parsed.success) {
  console.error("Invalid environment configuration:");
  for (const issue of parsed.error.issues) {
    console.error(`  ${issue.path.join(".")}: ${issue.message}`);
  }
  process.exit(1);
}

export const config = parsed.data;
