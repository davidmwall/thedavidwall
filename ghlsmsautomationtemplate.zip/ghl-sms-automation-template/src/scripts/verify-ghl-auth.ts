import { ghlClient } from "../ghl/client.js";

const contacts = await ghlClient.listContacts(1);
console.log(`Auth OK. Location has at least ${contacts.length} contact(s) visible.`);
if (contacts[0]) {
  console.log(`Sample contact: ${contacts[0].id} (${contacts[0].firstName ?? "?"})`);
}
