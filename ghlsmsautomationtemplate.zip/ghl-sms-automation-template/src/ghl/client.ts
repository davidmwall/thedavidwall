import { config } from "../config.js";
import { getAuthHeaders } from "./auth.js";

export class GhlApiError extends Error {
  constructor(
    public status: number,
    public body: unknown,
    message: string
  ) {
    super(message);
    this.name = "GhlApiError";
  }
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Retries on 429 with backoff (respecting Retry-After when GHL sends one).
 * Needed for any bulk/scripted read work against this API — a handful of
 * concurrent per-contact lookups is enough to trip GHL's rate limiter, and
 * once tripped it stays tripped for a stretch rather than clearing after one
 * retry, so this backs off meaningfully instead of hammering it.
 */
async function ghlFetch<T>(
  path: string,
  init: RequestInit = {},
  attempt = 0
): Promise<T> {
  const res = await fetch(`${config.GHL_API_BASE_URL}${path}`, {
    ...init,
    headers: {
      ...getAuthHeaders(),
      ...(init.headers ?? {}),
    },
  });

  if (res.status === 429 && attempt < 6) {
    const retryAfterHeader = res.headers.get("Retry-After");
    const retryAfterMs = retryAfterHeader ? Number(retryAfterHeader) * 1000 : null;
    const backoffMs = retryAfterMs ?? Math.min(1000 * 2 ** attempt, 30000);
    await sleep(backoffMs);
    return ghlFetch<T>(path, init, attempt + 1);
  }

  const text = await res.text();
  const body = text ? JSON.parse(text) : null;

  if (!res.ok) {
    throw new GhlApiError(
      res.status,
      body,
      `GHL API ${init.method ?? "GET"} ${path} failed: ${res.status}`
    );
  }

  return body as T;
}

export interface GhlContact {
  id: string;
  locationId: string;
  firstName?: string;
  lastName?: string;
  phone?: string;
  email?: string;
  state?: string;
  tags?: string[];
  [key: string]: unknown;
}

export interface GhlMessage {
  id: string;
  conversationId: string;
  direction: "inbound" | "outbound";
  body: string;
  dateAdded: string;
  [key: string]: unknown;
}

export interface GhlAppointment {
  id: string;
  contactId: string;
  calendarId: string;
  title?: string;
  appointmentStatus: string;
  /** "yyyy-MM-dd HH:mm:ss" in the calendar's configured location timezone, no offset. */
  startTime: string;
  endTime: string;
  deleted: boolean;
  [key: string]: unknown;
}

interface GhlSendMessageResponse {
  conversationId?: string;
  messageId?: string;
  msgId?: string;
  [key: string]: unknown;
}

export const ghlClient = {
  /** Cheap read used to smoke-test that auth + location id are correct. */
  async listContacts(limit = 1): Promise<GhlContact[]> {
    const data = await ghlFetch<{ contacts: GhlContact[] }>(
      `/contacts/?locationId=${config.GHL_LOCATION_ID}&limit=${limit}`
    );
    return data.contacts;
  },

  async getContact(contactId: string): Promise<GhlContact> {
    const data = await ghlFetch<{ contact: GhlContact }>(
      `/contacts/${contactId}`
    );
    return data.contact;
  },

  async findConversationByContact(contactId: string) {
    const data = await ghlFetch<{ conversations: Array<{ id: string }> }>(
      `/conversations/search?contactId=${contactId}&locationId=${config.GHL_LOCATION_ID}`
    );
    return data.conversations[0] ?? null;
  },

  async getMessages(conversationId: string): Promise<GhlMessage[]> {
    const data = await ghlFetch<{ messages: { messages: GhlMessage[] } }>(
      `/conversations/${conversationId}/messages`
    );
    return data.messages.messages;
  },

  async getAppointments(contactId: string): Promise<GhlAppointment[]> {
    const data = await ghlFetch<{ events: GhlAppointment[] }>(
      `/contacts/${contactId}/appointments`
    );
    return data.events;
  },

  async sendSms(contactId: string, message: string): Promise<GhlSendMessageResponse> {
    return ghlFetch<GhlSendMessageResponse>(`/conversations/messages`, {
      method: "POST",
      body: JSON.stringify({
        type: "SMS",
        contactId,
        message,
      }),
    });
  },

  async addTags(contactId: string, tags: string[]) {
    return ghlFetch(`/contacts/${contactId}/tags`, {
      method: "POST",
      body: JSON.stringify({ tags }),
    });
  },

  async removeTags(contactId: string, tags: string[]) {
    return ghlFetch(`/contacts/${contactId}/tags`, {
      method: "DELETE",
      body: JSON.stringify({ tags }),
    });
  },

  /**
   * Sets GHL's native Do Not Disturb flag on a contact - stronger than a
   * tag, since it's enforced by GHL itself and blocks the native drip
   * workflow's own sends too, not just our bot. Use for permanent
   * suppression (explicit opt-out, wrong number, deceased, etc.), not the
   * temporary bot-paused tag.
   */
  async setDnd(contactId: string): Promise<void> {
    await ghlFetch(`/contacts/${contactId}`, {
      method: "PUT",
      body: JSON.stringify({ dnd: true }),
    });
  },

  /**
   * startTime/endTime must be full ISO 8601 instants (e.g. with a "Z" or
   * explicit offset) — GHL displays them converted into the calendar's own
   * configured location timezone, so passing the correct UTC instant is
   * what makes cross-timezone booking show up correctly on the calendar.
   */
  async createAppointment(input: {
    contactId: string;
    startTime: string;
    endTime: string;
    title: string;
  }) {
    return ghlFetch(`/calendars/events/appointments`, {
      method: "POST",
      body: JSON.stringify({
        calendarId: config.GHL_CALENDAR_ID,
        locationId: config.GHL_LOCATION_ID,
        contactId: input.contactId,
        startTime: input.startTime,
        endTime: input.endTime,
        title: input.title,
        appointmentStatus: "confirmed",
      }),
    });
  },
};
