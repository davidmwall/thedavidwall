import { config } from "../config.js";

/**
 * Private Integration auth: a single static token scoped to one GHL
 * sub-account (Settings > Private Integrations). No refresh flow needed.
 * If this ever needs to support multiple locations via the GHL Marketplace,
 * swap this for an OAuth token store (per-location access/refresh tokens).
 */
export function getAuthHeaders(): Record<string, string> {
  return {
    Authorization: `Bearer ${config.GHL_PRIVATE_INTEGRATION_TOKEN}`,
    Version: config.GHL_API_VERSION,
    "Content-Type": "application/json",
  };
}
