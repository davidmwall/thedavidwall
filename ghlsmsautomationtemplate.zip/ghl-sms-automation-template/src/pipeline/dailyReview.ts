import { mkdirSync, writeFileSync } from "node:fs";
import { DateTime } from "luxon";
import { draftFollowUp } from "../claude/draft.js";
import { db, insertPendingDraft, isBotSentMessage } from "../db/index.js";
import { ghlClient } from "../ghl/client.js";
import { buildLeadContext } from "../leads/context.js";
import { sendApprovalRequest, sendOwnerConfirmation } from "../notify/ghlApprover.js";
import { BOT_PAUSED_TAG } from "./pauseCheck.js";

const OBJECTION_PATTERN =
  /\b(stop|not interested|no thanks|leave me alone|remove me|don'?t (contact|text|call) me|wrong number|do not (contact|call|text)|unsubscribe|quit (texting|calling))\b/i;

const SILENCE_THRESHOLD_HOURS = 12;

interface DeadEnd {
  contactId: string;
  name: string;
  lastBotMessage: string;
  reason: "silence" | "objection";
  leadReply?: string;
}

interface ManualSave {
  contactId: string;
  name: string;
  pauseReason: string;
  manualMessage: string;
  leadReplyAfter?: string;
}

function getRecentBotTouchedContactIds(sinceIso: string): string[] {
  const rows = db
    .prepare(`SELECT DISTINCT contact_id FROM bot_sent_messages WHERE sent_at >= ?`)
    .all(sinceIso) as { contact_id: string }[];
  return rows.map((r) => r.contact_id);
}

function getRecentPausedDraftContacts(
  sinceIso: string
): Array<{ contactId: string; reasoning: string }> {
  const rows = db
    .prepare(
      `SELECT DISTINCT contact_id as contactId, reasoning
       FROM pending_drafts
       WHERE reasoning LIKE '%PAUSED%' AND created_at >= ?`
    )
    .all(sinceIso) as Array<{ contactId: string; reasoning: string | null }>;
  return rows
    .filter((r): r is { contactId: string; reasoning: string } => Boolean(r.reasoning))
    .map((r) => ({ contactId: r.contactId, reasoning: r.reasoning }));
}

async function getLeadName(contactId: string): Promise<string> {
  const contact = await ghlClient.getContact(contactId);
  return [contact.firstName, contact.lastName].filter(Boolean).join(" ") || contactId;
}

async function classifyDeadEnd(contactId: string, name: string): Promise<DeadEnd | null> {
  const conversation = await ghlClient.findConversationByContact(contactId);
  if (!conversation) return null;

  const messages = await ghlClient.getMessages(conversation.id);
  messages.sort((a, b) => new Date(a.dateAdded).getTime() - new Date(b.dateAdded).getTime());

  let lastBotIdx = -1;
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    if (m.direction === "outbound" && isBotSentMessage(m.id)) {
      lastBotIdx = i;
      break;
    }
  }
  if (lastBotIdx === -1) return null;

  const lastBotMessage = messages[lastBotIdx];
  const after = messages
    .slice(lastBotIdx + 1)
    .filter((m) => m.direction === "inbound" && m.messageType === "TYPE_SMS");

  if (after.length === 0) {
    const hoursSince =
      (Date.now() - new Date(lastBotMessage.dateAdded).getTime()) / (1000 * 60 * 60);
    if (hoursSince >= SILENCE_THRESHOLD_HOURS) {
      return { contactId, name, lastBotMessage: lastBotMessage.body, reason: "silence" };
    }
    return null;
  }

  const firstReply = after[0];
  if (OBJECTION_PATTERN.test(firstReply.body)) {
    return {
      contactId,
      name,
      lastBotMessage: lastBotMessage.body,
      reason: "objection",
      leadReply: firstReply.body,
    };
  }

  return null;
}

async function findManualSave(
  contactId: string,
  reasoning: string,
  name: string
): Promise<ManualSave | null> {
  const conversation = await ghlClient.findConversationByContact(contactId);
  if (!conversation) return null;

  const messages = await ghlClient.getMessages(conversation.id);
  messages.sort((a, b) => new Date(a.dateAdded).getTime() - new Date(b.dateAdded).getTime());

  const manualIdx = messages.findIndex(
    (m) => m.direction === "outbound" && m.source !== "workflow" && !isBotSentMessage(m.id)
  );
  if (manualIdx === -1) return null;

  const replyAfter = messages
    .slice(manualIdx + 1)
    .find((m) => m.direction === "inbound" && m.messageType === "TYPE_SMS");

  const pauseReason = reasoning
    .replace(/^\[PAUSED:\s*/, "")
    .replace(/\].*$/s, "")
    .trim();

  return {
    contactId,
    name,
    pauseReason,
    manualMessage: messages[manualIdx].body,
    leadReplyAfter: replyAfter?.body,
  };
}

export async function runDailyReview(): Promise<{
  deadEnds: DeadEnd[];
  manualSaves: ManualSave[];
}> {
  const sinceIso = DateTime.now().minus({ hours: 24 }).toUTC().toSQL({ includeOffset: false })!;

  const deadEnds: DeadEnd[] = [];
  for (const contactId of getRecentBotTouchedContactIds(sinceIso)) {
    try {
      const name = await getLeadName(contactId);
      const result = await classifyDeadEnd(contactId, name);
      if (result) deadEnds.push(result);
    } catch (err) {
      console.error(
        `[daily-review] error checking dead-end for ${contactId}:`,
        err instanceof Error ? err.message : err
      );
    }
  }

  const manualSaves: ManualSave[] = [];
  for (const { contactId, reasoning } of getRecentPausedDraftContacts(sinceIso)) {
    try {
      const name = await getLeadName(contactId);
      const result = await findManualSave(contactId, reasoning, name);
      if (result) manualSaves.push(result);
    } catch (err) {
      console.error(
        `[daily-review] error checking manual save for ${contactId}:`,
        err instanceof Error ? err.message : err
      );
    }
  }

  return { deadEnds, manualSaves };
}

function formatReport(deadEnds: DeadEnd[], manualSaves: ManualSave[]): string {
  const lines: string[] = [
    `Daily review: ${deadEnds.length} dead-end${deadEnds.length === 1 ? "" : "s"}, ${manualSaves.length} manual save${manualSaves.length === 1 ? "" : "s"} in the last 24h.`,
  ];

  for (const d of deadEnds.slice(0, 3)) {
    lines.push(
      `\n[DEAD END - ${d.reason}] ${d.name}: "${d.lastBotMessage}"${
        d.leadReply ? ` -> lead said "${d.leadReply}"` : " -> no reply since"
      }`
    );
  }

  for (const s of manualSaves.slice(0, 3)) {
    lines.push(
      `\n[YOUR SAVE] ${s.name} (${s.pauseReason}): you said "${s.manualMessage}"${
        s.leadReplyAfter ? ` -> lead replied "${s.leadReplyAfter}"` : " -> no reply yet"
      }`
    );
  }

  if (deadEnds.length > 3 || manualSaves.length > 3) {
    lines.push(`\n...plus more - ask Claude Code to pull the full daily-review file for today.`);
  }

  return lines.join("\n");
}

/**
 * Drafts a re-engagement follow-up for every silence dead-end and holds it
 * for owner approval (YES/NO/EDIT), same as any other draft. Deliberately
 * skips "objection" dead-ends entirely - re-texting someone who already said
 * "no thanks" or worse is a good way to turn a soft decline into a
 * complaint or a real opt-out, so that's never automated. Also re-checks DND
 * and the bot-paused tag live (not just the classification from a few
 * minutes ago) since either could have changed since the scan ran.
 */
async function draftFollowUpsForSilence(deadEnds: DeadEnd[]): Promise<number> {
  let drafted = 0;
  for (const d of deadEnds.filter((x) => x.reason === "silence")) {
    try {
      const contact = await ghlClient.getContact(d.contactId);
      if (contact.dnd) continue;
      if (contact.tags?.includes(BOT_PAUSED_TAG)) continue;

      const { conversationId, messages } = await buildLeadContext({ contactId: d.contactId });
      const draftText = await draftFollowUp({ contact, messages });

      const draftId = insertPendingDraft({
        webhookEventId: null,
        contactId: d.contactId,
        conversationId,
        category: "follow_up",
        reasoning: `Daily review: silence dead-end, last bot message "${d.lastBotMessage}"`,
        draftText,
        status: "pending_approval",
      });

      await sendApprovalRequest({
        draftId,
        leadName: `${d.name} (follow-up)`,
        category: "follow_up",
        draftText,
      });

      drafted++;
    } catch (err) {
      console.error(
        `[daily-review] error drafting follow-up for ${d.contactId}:`,
        err instanceof Error ? err.message : err
      );
    }
  }
  return drafted;
}

export async function runAndNotifyDailyReview(): Promise<void> {
  const { deadEnds, manualSaves } = await runDailyReview();

  const today = DateTime.now().toFormat("yyyy-MM-dd");
  mkdirSync("data/daily-review", { recursive: true });
  writeFileSync(
    `data/daily-review/${today}.json`,
    JSON.stringify({ generatedAt: new Date().toISOString(), deadEnds, manualSaves }, null, 2)
  );

  if (deadEnds.length === 0 && manualSaves.length === 0) {
    console.log("[daily-review] nothing to report today");
    return;
  }

  const followUpsDrafted = await draftFollowUpsForSilence(deadEnds);

  await sendOwnerConfirmation(
    `${formatReport(deadEnds, manualSaves)}\n\nDrafted ${followUpsDrafted} follow-up${followUpsDrafted === 1 ? "" : "s"} for the silence dead-ends above - check your approval texts.`
  );
  console.log(
    `[daily-review] sent report: ${deadEnds.length} dead-ends, ${manualSaves.length} manual saves, ${followUpsDrafted} follow-ups drafted`
  );
}
