import { DateTime } from "luxon";
import type { DraftResult } from "../claude/draft.js";
import { config } from "../config.js";
import type { GhlContact } from "../ghl/client.js";
import { resolveLeadTimezone } from "../leads/timezone.js";
import { sendOwnerConfirmation } from "../notify/ghlApprover.js";

/**
 * The bot does NOT book the appointment itself — GHL sends a duplicate
 * confirmation text to the lead for appointments created via the public API
 * (see README "Known limitation"), so instead this computes the correct
 * business-timezone call time and texts the owner to book it themselves via
 * the normal "Add Appointment" button, which doesn't have that problem.
 */
export async function notifyAppointmentConfirmed(input: {
  contact: GhlContact;
  result: DraftResult;
  leadName: string;
}): Promise<void> {
  const { contact, result, leadName } = input;
  if (!result.appointmentConfirmed || !result.appointmentDate || !result.appointmentTime) {
    return;
  }

  const leadTimezone = resolveLeadTimezone(contact.state, config.BUSINESS_TIMEZONE);
  const start = DateTime.fromFormat(
    `${result.appointmentDate} ${result.appointmentTime}`,
    "yyyy-MM-dd HH:mm",
    { zone: leadTimezone }
  );

  if (!start.isValid) {
    console.error(
      `[booking] could not parse confirmed appointment "${result.appointmentDate} ${result.appointmentTime}" (${start.invalidReason}) for ${leadName}, skipping notification`
    );
    return;
  }

  const businessLocal = start.setZone(config.BUSINESS_TIMEZONE).toFormat("yyyy-MM-dd HH:mm ZZZZ");
  const leadLocal = start.toFormat("yyyy-MM-dd HH:mm ZZZZ");

  console.log(
    `[booking] appointment confirmed with ${leadName}: ${leadLocal} -> book for ${businessLocal} on your calendar`
  );

  await sendOwnerConfirmation(
    `${leadName} confirmed for ${result.appointmentDate} ${result.appointmentTime} their time (${leadTimezone}). Book it on your calendar for ${businessLocal}.`
  );
}
