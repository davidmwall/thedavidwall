import { isBotSentMessage } from "../db/index.js";
import type { GhlContact, GhlMessage } from "../ghl/client.js";
import { hasActiveAppointment } from "../leads/appointments.js";

export const BOT_PAUSED_TAG = "bot-paused";

/**
 * True if the bot has previously sent at least one message in this thread,
 * but the most recent outbound message is NOT one of the bot's own AND isn't
 * a native GHL workflow (drip) send either — i.e. the owner personally
 * jumped into a conversation the bot was running. A drip/workflow text
 * landing in the thread is not a takeover signal (it's just the campaign
 * doing its own thing) and must not pause the bot on its own.
 * Deliberately does NOT fire on a contact's very first-ever reply (the bot
 * has no footprint yet there) since that's the bot's normal job: picking up
 * a lead's first reply to an unrelated drip-campaign blast.
 */
function threadHasForeignInterruption(messages: GhlMessage[]): boolean {
  const botEverSentHere = messages.some(
    (m) => m.direction === "outbound" && isBotSentMessage(m.id)
  );
  if (!botEverSentHere) return false;

  const lastOutbound = [...messages].reverse().find((m) => m.direction === "outbound");
  if (!lastOutbound) return false;
  if (lastOutbound.source === "workflow") return false;
  return !isBotSentMessage(lastOutbound.id);
}

/**
 * Returns a human-readable reason the bot should stay out of this contact's
 * conversation, or null if it's safe to draft/send as usual.
 *
 * `skipForeignInterruptionCheck` is for manually-triggered reprocessing
 * (owner has personally reviewed the thread and explicitly asked for a
 * reply) - the foreign-interruption check exists to defer to human judgment
 * when the bot isn't sure it's safe to jump back in, and an explicit manual
 * trigger already *is* that human judgment call. The bot-paused tag and
 * active-appointment checks still apply even then, since those are stronger,
 * more specific signals a manual review might not have caught.
 */
export async function getPauseReason(
  contact: GhlContact,
  messages: GhlMessage[],
  options: { skipForeignInterruptionCheck?: boolean } = {}
): Promise<string | null> {
  if (contact.tags?.includes(BOT_PAUSED_TAG)) {
    return "already tagged bot-paused";
  }
  if (await hasActiveAppointment(contact.id)) {
    return "has an active/upcoming appointment on the calendar";
  }
  if (!options.skipForeignInterruptionCheck && threadHasForeignInterruption(messages)) {
    return "a non-bot message appeared in this thread (you or another workflow already responded)";
  }
  return null;
}
