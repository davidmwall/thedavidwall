import { draftReply } from "../claude/draft.js";
import { insertPendingDraft, markWebhookEventProcessed, recordBotSentMessage } from "../db/index.js";
import { ghlClient } from "../ghl/client.js";
import { buildLeadContext } from "../leads/context.js";
import { sendApprovalRequest, sendCarrierAlert, sendOwnerConfirmation } from "../notify/ghlApprover.js";
import { notifyAppointmentConfirmed } from "./notifyAppointment.js";
import { BOT_PAUSED_TAG, getPauseReason } from "./pauseCheck.js";

export async function handleInboundEvent(input: {
  webhookEventId: number;
  contactId: string;
  conversationId?: string | null;
  skipForeignInterruptionCheck?: boolean;
}): Promise<void> {
  try {
    const { contact, conversationId, messages } = await buildLeadContext({
      contactId: input.contactId,
      conversationId: input.conversationId,
    });

    const leadName =
      [contact.firstName, contact.lastName].filter(Boolean).join(" ") ||
      contact.phone ||
      contact.id;

    const pauseReason = await getPauseReason(contact, messages, {
      skipForeignInterruptionCheck: input.skipForeignInterruptionCheck,
    });
    if (pauseReason) {
      console.log(`[pipeline] ${leadName} is paused (${pauseReason}) - drafting for review instead of auto-handling`);
      if (!contact.tags?.includes(BOT_PAUSED_TAG)) {
        await ghlClient.addTags(contact.id, [BOT_PAUSED_TAG]);
      }

      // Paused doesn't mean "go dark" - the tag can be wrong (added by
      // mistake, or the pause condition was a false positive), so still
      // draft what the bot would have sent and hold it for a human
      // decision instead of silently doing nothing on every future message
      // from this contact.
      try {
        const result = await draftReply({ contact, messages });
        const draftId = insertPendingDraft({
          webhookEventId: input.webhookEventId,
          contactId: contact.id,
          conversationId,
          category: result.category,
          reasoning: `[PAUSED: ${pauseReason}] ${result.reasoning}`,
          draftText: result.draft,
          status: "pending_approval",
        });
        await sendApprovalRequest({
          draftId,
          leadName: `${leadName} (paused: ${pauseReason})`,
          category: result.category,
          draftText: result.draft || "(no reply needed)",
        });
        console.log(`[pipeline] held draft #${draftId} for paused contact ${leadName}`);
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        console.error(`[pipeline] failed to draft for paused contact ${leadName}:`, message);
        await sendOwnerConfirmation(
          `${leadName} sent a new message but is paused (${pauseReason}) and I couldn't draft a reply (${message}). Check GHL directly.`
        );
      }

      markWebhookEventProcessed(input.webhookEventId, `paused: ${pauseReason} (drafted for review)`);
      return;
    }

    const result = await draftReply({ contact, messages });

    // Defense in depth: a carrier mention always holds for a human takeover,
    // regardless of what category Claude assigned.
    const effectiveCategory = result.carrierMentioned ? "needs_approval" : result.category;

    if (effectiveCategory === "no_reply") {
      console.log(`[pipeline] no reply needed for ${leadName}: ${result.reasoning}`);
      markWebhookEventProcessed(input.webhookEventId, `no_reply: ${result.reasoning}`);
      return;
    }

    if (effectiveCategory === "logistics") {
      const sendResult = await ghlClient.sendSms(contact.id, result.draft);
      recordBotSentMessage(sendResult.messageId ?? sendResult.msgId, contact.id);
      insertPendingDraft({
        webhookEventId: input.webhookEventId,
        contactId: contact.id,
        conversationId,
        category: effectiveCategory,
        reasoning: result.reasoning,
        draftText: result.draft,
        status: "auto_sent",
      });
      console.log(`[pipeline] auto-sent logistics reply to ${leadName}`);

      try {
        await notifyAppointmentConfirmed({ contact, result, leadName });
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        console.error(`[pipeline] appointment notification failed for ${leadName}:`, message);
      }
    } else {
      const draftId = insertPendingDraft({
        webhookEventId: input.webhookEventId,
        contactId: contact.id,
        conversationId,
        category: effectiveCategory,
        reasoning: result.reasoning,
        draftText: result.draft,
        status: "pending_approval",
      });

      if (result.carrierMentioned) {
        const lastMessage = messages[messages.length - 1]?.body ?? "";
        await sendCarrierAlert({
          draftId,
          leadName,
          carrierName: result.carrierName ?? "unspecified carrier",
          lastMessage,
        });
        console.log(
          `[pipeline] held draft #${draftId} and sent carrier takeover alert (${leadName}, ${result.carrierName})`
        );
      } else {
        await sendApprovalRequest({
          draftId,
          leadName,
          category: effectiveCategory,
          draftText: result.draft,
        });
        console.log(
          `[pipeline] held draft #${draftId} for approval (${leadName}, ${effectiveCategory})`
        );
      }
    }

    markWebhookEventProcessed(input.webhookEventId);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error(`[pipeline] failed to process webhook event #${input.webhookEventId}:`, message);
    markWebhookEventProcessed(input.webhookEventId, message);
  }
}
