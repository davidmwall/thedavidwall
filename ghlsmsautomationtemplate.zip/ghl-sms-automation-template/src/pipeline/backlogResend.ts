import { readFileSync } from "node:fs";
import { join } from "node:path";
import { insertWebhookEvent, recordBotSentMessage } from "../db/index.js";
import { ghlClient } from "../ghl/client.js";
import { handleInboundEvent } from "./handleInboundEvent.js";

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// Spacing between individual sends so this doesn't trip GHL's own send-rate
// limiter the way the read-side investigation scripts initially did.
const PACE_MS = 2000;

interface StoredMessageCandidate {
  contactId: string;
  name: string;
  body: string;
}

interface NoResponseCandidate {
  contactId: string;
  name: string;
  leadLastMessage?: string;
}

function loadJson<T>(filename: string): T {
  const path = join(process.cwd(), "data", "backlog-resend", filename);
  return JSON.parse(readFileSync(path, "utf-8")) as T;
}

async function resendStoredMessage(candidate: StoredMessageCandidate, label: string): Promise<void> {
  try {
    const sendResult = await ghlClient.sendSms(candidate.contactId, candidate.body);
    recordBotSentMessage(sendResult.messageId ?? sendResult.msgId, candidate.contactId);
    console.log(`[backlog-resend] ${label}: resent to ${candidate.name} (${candidate.contactId})`);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error(
      `[backlog-resend] ${label}: FAILED for ${candidate.name} (${candidate.contactId}): ${message}`
    );
  }
}

/**
 * These contacts never got any reply drafted in the first place, so there's
 * nothing stored to resend - runs them back through the real inbound
 * pipeline (same pause checks, classification, and DB bookkeeping as live
 * traffic) so it drafts a reply against their current conversation state.
 */
async function regenerateFreshReply(candidate: NoResponseCandidate): Promise<void> {
  try {
    const webhookEventId = insertWebhookEvent({
      eventType: "backlog_resend_regenerate",
      contactId: candidate.contactId,
      conversationId: null,
      payload: {
        reason: "no_response_at_all backlog resend",
        leadLastMessage: candidate.leadLastMessage ?? null,
      },
    });
    await handleInboundEvent({ webhookEventId, contactId: candidate.contactId });
    console.log(
      `[backlog-resend] no_response_at_all: regenerated reply for ${candidate.name} (${candidate.contactId})`
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error(
      `[backlog-resend] no_response_at_all: FAILED for ${candidate.name} (${candidate.contactId}): ${message}`
    );
  }
}

export async function runBacklogResend(): Promise<void> {
  const failedResponse = loadJson<StoredMessageCandidate[]>("failed-response.json");
  const noResponseAtAll = loadJson<NoResponseCandidate[]>("no-response-at-all.json");
  const blastOnly = loadJson<StoredMessageCandidate[]>("blast-only-failure.json");

  console.log(
    `[backlog-resend] starting: ${failedResponse.length} failed_response, ${noResponseAtAll.length} no_response_at_all, ${blastOnly.length} blast_only_failure`
  );

  for (const c of failedResponse) {
    await resendStoredMessage(c, "failed_response");
    await sleep(PACE_MS);
  }

  for (const c of noResponseAtAll) {
    await regenerateFreshReply(c);
    await sleep(PACE_MS);
  }

  for (const c of blastOnly) {
    await resendStoredMessage(c, "blast_only");
    await sleep(PACE_MS);
  }

  console.log("[backlog-resend] complete.");
}
