import { DateTime } from "luxon";
import { config } from "../config.js";
import { runAndNotifyDailyReview } from "../pipeline/dailyReview.js";

// End of business day, business-local time - late enough that the day's
// conversations have mostly played out, so the silence-detection window in
// dailyReview.ts (12h+ since the bot's last message) has real signal.
const DAILY_REVIEW_HOUR = 21;

function msUntilNextRun(): number {
  const now = DateTime.now().setZone(config.BUSINESS_TIMEZONE);
  let next = now.set({ hour: DAILY_REVIEW_HOUR, minute: 0, second: 0, millisecond: 0 });
  if (next <= now) next = next.plus({ days: 1 });
  return next.diff(now).toMillis();
}

export function scheduleDailyReview(): void {
  const delay = msUntilNextRun();
  console.log(
    `[daily-review] next run at ${DateTime.now().setZone(config.BUSINESS_TIMEZONE).plus({ milliseconds: delay }).toFormat("yyyy-MM-dd HH:mm ZZZZ")}`
  );
  setTimeout(() => {
    runAndNotifyDailyReview()
      .catch((err) => {
        console.error("[daily-review] scheduled run failed:", err instanceof Error ? err.message : err);
      })
      .finally(() => scheduleDailyReview());
  }, delay);
}
