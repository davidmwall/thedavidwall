import { DateTime } from "luxon";
import { config } from "../config.js";
import { ghlClient } from "../ghl/client.js";

/**
 * True if this contact has a non-deleted, non-cancelled appointment landing
 * within the last 24h through the next 30 days. Appointment start/end times
 * come back from GHL as naive "yyyy-MM-dd HH:mm:ss" strings in the calendar's
 * configured location timezone (BUSINESS_TIMEZONE), not UTC.
 */
export async function hasActiveAppointment(contactId: string): Promise<boolean> {
  const events = await ghlClient.getAppointments(contactId);
  const now = DateTime.now().setZone(config.BUSINESS_TIMEZONE);

  return events.some((event) => {
    if (event.deleted) return false;
    if (event.appointmentStatus === "cancelled") return false;

    const start = DateTime.fromFormat(event.startTime, "yyyy-MM-dd HH:mm:ss", {
      zone: config.BUSINESS_TIMEZONE,
    });
    if (!start.isValid) return false;

    return start > now.minus({ hours: 24 }) && start < now.plus({ days: 30 });
  });
}
