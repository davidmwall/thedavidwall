import { ghlClient, type GhlContact, type GhlMessage } from "../ghl/client.js";

export interface LeadContext {
  contact: GhlContact;
  conversationId: string;
  messages: GhlMessage[];
}

/**
 * Resolves the conversation for a webhook event and pulls the full message
 * thread + contact/lead data needed to draft a reply. Falls back to looking
 * up the conversation by contact if the webhook payload didn't include one.
 */
export async function buildLeadContext(input: {
  contactId: string;
  conversationId?: string | null;
}): Promise<LeadContext> {
  const [contact, conversationId] = await Promise.all([
    ghlClient.getContact(input.contactId),
    input.conversationId
      ? Promise.resolve(input.conversationId)
      : resolveConversationId(input.contactId),
  ]);

  const messages = await ghlClient.getMessages(conversationId);

  // GHL returns messages newest-first; drafting wants chronological order.
  messages.sort(
    (a, b) => new Date(a.dateAdded).getTime() - new Date(b.dateAdded).getTime()
  );

  return { contact, conversationId, messages };
}

async function resolveConversationId(contactId: string): Promise<string> {
  const conversation = await ghlClient.findConversationByContact(contactId);
  if (!conversation) {
    throw new Error(`No conversation found for contact ${contactId}`);
  }
  return conversation.id;
}
