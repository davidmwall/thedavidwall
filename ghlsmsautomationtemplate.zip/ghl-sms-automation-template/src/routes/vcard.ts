import { Router } from "express";
import { config } from "../config.js";

export const vcardRouter = Router();

// Minimal test vCard - swap in real details once the attachment mechanism
// is confirmed to actually render as a native "Add Contact" card.
const TEST_VCARD = [
  "BEGIN:VCARD",
  "VERSION:3.0",
  `FN:${config.AGENT_NAME}`,
  `N:;${config.AGENT_NAME};;;`,
  "TEL;TYPE=CELL:+10000000000",
  "ORG:Insurance",
  "END:VCARD",
].join("\r\n");

vcardRouter.get("/contact.vcf", (_req, res) => {
  res.setHeader("Content-Type", "text/vcard");
  res.setHeader("Content-Disposition", 'attachment; filename="contact.vcf"');
  res.status(200).send(TEST_VCARD);
});
