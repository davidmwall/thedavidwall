import { Router } from "express";
import { config } from "../config.js";
import {
  getMostRecentPendingApproval,
  getPendingDraft,
  insertWebhookEvent,
  markWebhookEventProcessed,
  recordBotSentMessage,
  resolvePendingDraft,
  type PendingDraftRow,
} from "../db/index.js";
import { ghlClient } from "../ghl/client.js";
import { sendOwnerConfirmation } from "../notify/ghlApprover.js";
import { ghlWebhookPayloadSchema } from "../types/webhook.js";

export const ghlApprovalRouter = Router();

const YES_RE = /^\s*YES\s*(\d+)?/i;
const NO_RE = /^\s*NO\s*(\d+)?/i;
const EDIT_RE = /^\s*EDIT\s*(\d+)?\s*:\s*([\s\S]+)/i;

ghlApprovalRouter.post("/ghl-approval", (req, res) => {
  const providedSecret = req.header("x-webhook-secret");
  if (providedSecret !== config.GHL_WEBHOOK_SECRET) {
    res.status(401).json({ error: "invalid webhook secret" });
    return;
  }

  const parsed = ghlWebhookPayloadSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "malformed payload", details: parsed.error.flatten() });
    return;
  }

  const payload = parsed.data;
  const contactId = payload.contact_id;
  const messageBody = payload.message?.body;

  const eventId = insertWebhookEvent({
    eventType: "owner_reply",
    contactId: contactId ?? null,
    conversationId: null,
    payload,
  });

  res.status(200).json({ received: true, eventId });

  if (contactId !== config.GHL_OWNER_CONTACT_ID) {
    console.warn(`[ghl-approval] ignoring reply from non-owner contact ${contactId}`);
    markWebhookEventProcessed(eventId, "ignored: not the owner contact");
    return;
  }

  if (!messageBody) {
    markWebhookEventProcessed(eventId, "ignored: no message body");
    return;
  }

  routeApprovalReply(messageBody)
    .then(() => markWebhookEventProcessed(eventId))
    .catch((err) => {
      const message = err instanceof Error ? err.message : String(err);
      console.error("[ghl-approval] failed to process reply:", message);
      markWebhookEventProcessed(eventId, message);
      void sendOwnerConfirmation(`Error processing that reply: ${message}`);
    });
});

async function routeApprovalReply(body: string): Promise<void> {
  let match: RegExpMatchArray | null;

  if ((match = body.match(YES_RE))) {
    const draft = await resolveTarget(match[1]);
    if (!draft) return;
    const sendResult = await ghlClient.sendSms(draft.contact_id, draft.draft_text);
    recordBotSentMessage(sendResult.messageId ?? sendResult.msgId, draft.contact_id);
    resolvePendingDraft(draft.id, "approved_sent");
    await sendOwnerConfirmation(`Sent #${draft.id} as drafted.`);
    return;
  }

  if ((match = body.match(NO_RE))) {
    const draft = await resolveTarget(match[1]);
    if (!draft) return;
    resolvePendingDraft(draft.id, "rejected");
    await sendOwnerConfirmation(`Rejected #${draft.id}. Nothing was sent.`);
    return;
  }

  if ((match = body.match(EDIT_RE))) {
    const draft = await resolveTarget(match[1]);
    if (!draft) return;
    const editedText = match[2].trim();
    const sendResult = await ghlClient.sendSms(draft.contact_id, editedText);
    recordBotSentMessage(sendResult.messageId ?? sendResult.msgId, draft.contact_id);
    resolvePendingDraft(draft.id, "edited_sent", editedText);
    await sendOwnerConfirmation(`Sent your edited version of #${draft.id}.`);
    return;
  }

  await sendOwnerConfirmation(
    `Didn't understand that. Reply "YES <id>", "NO <id>", or "EDIT <id>: <text>".`
  );
}

async function resolveTarget(idText: string | undefined): Promise<PendingDraftRow | null> {
  const draft = idText ? getPendingDraft(Number(idText)) : getMostRecentPendingApproval();

  if (!draft) {
    await sendOwnerConfirmation(
      idText ? `No draft found with id #${idText}.` : `No pending draft to act on.`
    );
    return null;
  }

  if (draft.status !== "pending_approval") {
    await sendOwnerConfirmation(`Draft #${draft.id} was already resolved (${draft.status}).`);
    return null;
  }

  return draft;
}
