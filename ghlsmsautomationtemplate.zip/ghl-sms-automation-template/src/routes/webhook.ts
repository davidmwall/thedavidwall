import { Router } from "express";
import { config } from "../config.js";
import { insertWebhookEvent, markWebhookEventProcessed } from "../db/index.js";
import { handleInboundEvent } from "../pipeline/handleInboundEvent.js";
import { ghlWebhookPayloadSchema } from "../types/webhook.js";

export const webhookRouter = Router();

webhookRouter.post("/ghl", (req, res) => {
  const providedSecret = req.header("x-webhook-secret");
  if (providedSecret !== config.GHL_WEBHOOK_SECRET) {
    res.status(401).json({ error: "invalid webhook secret" });
    return;
  }

  const parsed = ghlWebhookPayloadSchema.safeParse(req.body);
  if (!parsed.success) {
    console.error("Rejected malformed GHL webhook payload:", parsed.error.flatten());
    res.status(400).json({ error: "malformed payload", details: parsed.error.flatten() });
    return;
  }

  const payload = parsed.data;
  const contactId = payload.contact_id;

  const eventId = insertWebhookEvent({
    eventType: "inbound_sms",
    contactId: contactId ?? null,
    conversationId: null,
    payload,
  });

  console.log(`[webhook] logged event #${eventId} contact=${contactId ?? "?"}`);

  // Ack immediately so GHL's workflow webhook action doesn't time out; the
  // GHL/Claude API calls happen after the response is sent.
  res.status(200).json({ received: true, eventId });

  if (!contactId) {
    markWebhookEventProcessed(eventId, "payload missing contact_id, skipped");
    return;
  }

  void handleInboundEvent({
    webhookEventId: eventId,
    contactId,
  });
});
