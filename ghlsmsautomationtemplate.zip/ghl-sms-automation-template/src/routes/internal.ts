import { readFileSync } from "node:fs";
import { Router } from "express";
import { draftReply } from "../claude/draft.js";
import { config } from "../config.js";
import { insertPendingDraft, insertWebhookEvent, recordBotSentMessage } from "../db/index.js";
import { ghlClient } from "../ghl/client.js";
import { buildLeadContext } from "../leads/context.js";
import { sendApprovalRequest } from "../notify/ghlApprover.js";
import { runBacklogResend } from "../pipeline/backlogResend.js";
import { runAndNotifyDailyReview } from "../pipeline/dailyReview.js";
import { handleInboundEvent } from "../pipeline/handleInboundEvent.js";

export const internalRouter = Router();

function checkSecret(req: import("express").Request, res: import("express").Response): boolean {
  const providedSecret = req.header("x-internal-secret");
  if (!config.INTERNAL_JOB_SECRET || providedSecret !== config.INTERNAL_JOB_SECRET) {
    res.status(401).json({ error: "invalid internal secret" });
    return false;
  }
  return true;
}

internalRouter.post("/run-backlog-resend", (req, res) => {
  if (!checkSecret(req, res)) return;

  console.log("[backlog-resend] triggered via /internal/run-backlog-resend");
  res.status(202).json({ started: true });

  void runBacklogResend().catch((err) => {
    console.error("[backlog-resend] job crashed:", err instanceof Error ? err.message : err);
  });
});

/**
 * Scans the last 24h for dead-end threads (bot sent something, lead went
 * silent or hard-objected) and manual saves (owner personally revived a
 * paused thread), and texts the owner a digest. Runs on its own daily
 * schedule (see scheduleDailyReview in server.ts) - this route exists so it
 * can also be triggered on demand for testing.
 */
internalRouter.post("/run-daily-review", (req, res) => {
  if (!checkSecret(req, res)) return;

  console.log("[daily-review] triggered via /internal/run-daily-review");
  res.status(202).json({ started: true });

  void runAndNotifyDailyReview().catch((err) => {
    console.error("[daily-review] job crashed:", err instanceof Error ? err.message : err);
  });
});

/** Read back a past daily-review report (defaults to today) - full detail, not just the SMS digest. */
internalRouter.get("/daily-review/:date?", (req, res) => {
  if (!checkSecret(req, res)) return;

  const date = req.params.date ?? new Date().toISOString().slice(0, 10);
  try {
    const contents = readFileSync(`data/daily-review/${date}.json`, "utf-8");
    res.status(200).type("application/json").send(contents);
  } catch {
    res.status(404).json({ error: `no report found for ${date}` });
  }
});

/**
 * Reprocess a single contact through the live pipeline on demand - e.g. a
 * lead whose message never got a reply for some reason and the owner has
 * personally reviewed and wants a response drafted now. Deliberately
 * separate from the bulk job so it can be used without any risk of
 * interfering with a bulk run that might be in flight.
 */
internalRouter.post("/process-contact", (req, res) => {
  if (!checkSecret(req, res)) return;

  const contactId = req.body?.contactId as string | undefined;
  if (!contactId) {
    res.status(400).json({ error: "contactId is required" });
    return;
  }
  // Explicit opt-in per call, not a default - the foreign-interruption pause
  // exists precisely to prevent the bot re-engaging a thread something else
  // already touched, and that should stay the default even for manual
  // reprocessing. Only bypass it when the caller deliberately asks to.
  const skipForeignInterruptionCheck = req.body?.skipForeignInterruptionCheck === true;

  console.log(
    `[process-contact] triggered for ${contactId}${skipForeignInterruptionCheck ? " (skipping foreign-interruption check)" : ""}`
  );
  res.status(202).json({ started: true, contactId, skipForeignInterruptionCheck });

  const webhookEventId = insertWebhookEvent({
    eventType: "manual_reprocess",
    contactId,
    conversationId: null,
    payload: { reason: "manual reprocess via /internal/process-contact", skipForeignInterruptionCheck },
  });

  void handleInboundEvent({ webhookEventId, contactId, skipForeignInterruptionCheck }).catch((err) => {
    console.error(
      `[process-contact] failed for ${contactId}:`,
      err instanceof Error ? err.message : err
    );
  });
});

/**
 * Draft a reply for a contact and always hold it for owner review - never
 * auto-sends to the lead regardless of what category Claude assigns. For
 * cases the owner wants to see and approve/edit/reject before anything
 * reaches the client, rather than trusting the normal auto-send/hold split.
 */
internalRouter.post("/draft-for-review", (req, res) => {
  if (!checkSecret(req, res)) return;

  const contactId = req.body?.contactId as string | undefined;
  if (!contactId) {
    res.status(400).json({ error: "contactId is required" });
    return;
  }

  console.log(`[draft-for-review] triggered for ${contactId}`);
  res.status(202).json({ started: true, contactId });

  const webhookEventId = insertWebhookEvent({
    eventType: "manual_draft_for_review",
    contactId,
    conversationId: null,
    payload: { reason: "manual draft-for-review via /internal/draft-for-review" },
  });

  (async () => {
    const { contact, conversationId, messages } = await buildLeadContext({ contactId });
    const leadName =
      [contact.firstName, contact.lastName].filter(Boolean).join(" ") ||
      contact.phone ||
      contact.id;

    const result = await draftReply({ contact, messages });

    const draftId = insertPendingDraft({
      webhookEventId,
      contactId: contact.id,
      conversationId,
      category: result.category,
      reasoning: result.reasoning,
      draftText: result.draft,
      status: "pending_approval",
    });

    await sendApprovalRequest({
      draftId,
      leadName,
      category: result.category,
      draftText: result.draft,
    });

    console.log(`[draft-for-review] held draft #${draftId} for ${leadName} (${result.category})`);
  })().catch((err) => {
    console.error(
      `[draft-for-review] failed for ${contactId}:`,
      err instanceof Error ? err.message : err
    );
  });
});

/**
 * Send an owner-composed proactive message to a lead - for cases the
 * reactive pipeline isn't built for, e.g. following through on a promise
 * ("I'll check back tomorrow") when the lead hasn't said anything new to
 * react to. Not AI-drafted; the caller supplies the exact text.
 */
internalRouter.post("/send-manual", (req, res) => {
  if (!checkSecret(req, res)) return;

  const contactId = req.body?.contactId as string | undefined;
  const message = req.body?.message as string | undefined;
  if (!contactId || !message) {
    res.status(400).json({ error: "contactId and message are required" });
    return;
  }

  console.log(`[send-manual] sending to ${contactId}: "${message}"`);
  res.status(202).json({ started: true, contactId });

  void ghlClient
    .sendSms(contactId, message)
    .then((sendResult) => {
      recordBotSentMessage(sendResult.messageId ?? sendResult.msgId, contactId);
      console.log(`[send-manual] sent to ${contactId}`);
    })
    .catch((err) => {
      console.error(`[send-manual] failed for ${contactId}:`, err instanceof Error ? err.message : err);
    });
});
