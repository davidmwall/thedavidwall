import { config } from "../config.js";
import { ghlClient } from "../ghl/client.js";

/**
 * Approval-hold notifications sent over a regular GHL number to a GHL
 * contact record representing the business owner, instead of a separate
 * Twilio account. Replies are caught by a GHL workflow scoped to that
 * contact and routed to POST /webhooks/ghl-approval.
 */
export async function sendApprovalRequest(input: {
  draftId: number;
  leadName: string;
  category: string;
  draftText: string;
}): Promise<void> {
  const body = [
    `Reply needed for ${input.leadName} (#${input.draftId}, ${input.category}):`,
    `"${input.draftText}"`,
    ``,
    `Reply YES ${input.draftId} to send, NO ${input.draftId} to reject, or EDIT ${input.draftId}: <your text> to send your own version.`,
  ].join("\n");

  await ghlClient.sendSms(config.GHL_OWNER_CONTACT_ID, body);
}

/**
 * Sent instead of the normal YES/NO/EDIT approval text when a lead names a
 * carrier — this needs a human takeover, not an approve/edit/reject cycle.
 */
export async function sendCarrierAlert(input: {
  draftId: number;
  leadName: string;
  carrierName: string;
  lastMessage: string;
}): Promise<void> {
  const body = [
    `TAKE OVER: ${input.leadName} mentioned carrier "${input.carrierName}".`,
    `"${input.lastMessage}"`,
    ``,
    `Draft on file if you want it (#${input.draftId}): YES ${input.draftId} to send, EDIT ${input.draftId}: <your text> to send your own.`,
  ].join("\n");

  await ghlClient.sendSms(config.GHL_OWNER_CONTACT_ID, body);
}

/**
 * Best-effort: this is a follow-up confirmation, not the primary action
 * (the send/reject/edit already happened). Swallow failures so a GHL
 * hiccup here can't crash request handling or mask the real error.
 */
export async function sendOwnerConfirmation(body: string): Promise<void> {
  try {
    await ghlClient.sendSms(config.GHL_OWNER_CONTACT_ID, body);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error("[notify] failed to send owner confirmation:", message);
  }
}
