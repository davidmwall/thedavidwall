# Setup guide

This is an SMS assistant for insurance lead follow-up on GoHighLevel (GHL). It
watches for inbound lead replies, drafts a response with Claude, auto-sends
pure scheduling replies, and holds anything involving price/coverage/health
for your approval — texted to you over your own GHL number, no separate SMS
provider needed. It also runs a nightly review of dead threads and drafts
follow-ups for you to approve, and can text you a "carrier objection" script
for leads who say they already have coverage.

You have Claude Code already, so the fastest way through this is: open this
folder in Claude Code and say **"walk me through SETUP.md, filling in .env as
we go"** — it can run the commands, create the workflows via browser if you
give it access, and deploy for you. Everything below is also doable by hand.

---

## 0. Decide what to keep (read this first)

This is a straight copy of a working setup, not a generic template — some of
it needs a quick decision on your end before you turn it on:

- [ ] **The campaign script wording** (`src/claude/draft.ts`, "Mortgage
      protection campaign script" section). This describes the *exact*
      outbound text your drip campaign sends, so the bot can recognize when a
      lead is replying to it. If your outbound campaign text isn't word-for-
      word what's in that file right now, update it to match yours — the bot
      only follows the scripted decision tree when it recognizes that exact
      opener.
- [ ] **The booking negotiation script** (`src/claude/draft.ts`, item 2's
      bullets plus "Locking in the appointment"). This is a real, tested
      call-script adaptation — packed-calendar scarcity framing, a spouse
      check, and a final lock-in message asking the lead to keep their phone
      nearby and text ahead if they need to reschedule. Read through it and
      decide if the tone/tactics match how you want to sound, or strip parts
      out.
- [ ] **The carrier-objection / replacement script** (`src/claude/draft.ts`,
      "Handling carrier mentions and coverage objections"). This is the most
      business-specific part of the whole file — it assumes every lead
      already has a policy, treats "not interested" as something to push
      past rather than accept, and includes a scripted line asking about
      specific health conditions (e.g. "were you diagnosed with kidney
      failure or a heart attack") as part of a rate-class-correction pitch.
      This is a real, deliberate sales technique — read it carefully and
      make sure it's something you actually want your bot saying to leads
      before you turn it on. Strip or rewrite it if it doesn't fit your
      business or you're not comfortable with the framing.
- [ ] **Your name.** Set `AGENT_NAME` in `.env` to whatever you want the bot
      signing texts as (e.g. "Jack"). No code changes needed for this one.
- [ ] **Carrier list** (`src/claude/draft.ts`, "Handling carrier mentions..."
      section). Currently lists Mutual of Omaha, Foresters, Americo, AIG,
      Gerber Life, SBLI as examples — it already catches any other company
      name too, so this is optional, but swap in the carriers you actually
      work with if you want the examples to match.
- [ ] **Your business timezone.** Set `BUSINESS_TIMEZONE` in `.env` (IANA
      format, e.g. `America/Chicago`) — used to work out the correct call-time
      when a lead in a different timezone confirms an appointment.
- [ ] **The 3-day booking cap** (`src/claude/draft.ts`, "Appointments"
      section). The bot currently refuses to book anything more than 3 days
      out and pushes for something sooner instead — change or remove that if
      you want a longer booking window.
- [x] Tone/persona rules, the appointment-notify flow, the no-reply logic, the
      pause-on-active-appointment/foreign-message logic, and the daily review
      job are all general-purpose — recommended to keep as-is unless you know
      you want something different.

---

## 1. Prerequisites

- Node.js 20+
- A GHL sub-account with admin access
- An Anthropic API key (console.anthropic.com)
- A Railway account (railway.app) for hosting, or any other Node host

## 2. Install

```bash
npm install
```

## 3. Create the GHL Private Integration

In your GHL sub-account: **Settings > Private Integrations > Create new
integration**. Scopes needed:
`contacts.readonly`, `contacts.write`, `conversations.readonly`,
`conversations/message.readonly`, `conversations/message.write`.

Copy the token and your location ID (visible in the sub-account URL or
Settings > Business Info).

## 4. Set up your own contact as the approver

Held drafts get texted to *you*, not to a Slack channel or email — over your
own GHL number, to a GHL contact record representing you:

1. Create a contact for yourself in GHL (e.g. "Owner / Approver") with your
   personal cell number as the phone field, or reuse an existing one.
2. Tag it `internal-approver`.
3. Copy its contact ID from the URL (`.../contacts/detail/<contactId>`).

## 5. Fill in `.env`

```bash
cp .env.example .env
```

Fill in every blank value — `GHL_LOCATION_ID`, `GHL_PRIVATE_INTEGRATION_TOKEN`,
`ANTHROPIC_API_KEY`, `AGENT_NAME`, `GHL_OWNER_CONTACT_ID`, and generate both
`GHL_WEBHOOK_SECRET` and `INTERNAL_JOB_SECRET` with:

```bash
openssl rand -hex 24
```

`INTERNAL_JOB_SECRET` gates the `/internal/*` admin routes (backlog resend,
daily review, manual reprocess) — required if you want those, optional
otherwise.

## 6. Build the two GHL workflows

GHL workflows can't be exported/imported between accounts, so these need to
be built by hand in your account (Claude Code can do this via browser
automation if you give it access to a logged-in GHL tab).

**Workflow 1 — lead replies.** Trigger: **Customer replied**, filtered to
`Message body does not contain "confirm"` (avoids double-firing with any
existing confirm-reply workflow you have) and `Doesn't have tag:
internal-approver` (so your own approval replies never get treated as a lead
message). Add a **Webhook** action:
- URL: `https://<your-deployed-host>/webhooks/ghl`
- Method: POST
- Header: `x-webhook-secret: <same value as GHL_WEBHOOK_SECRET>`
- No custom data needed — the server reads GHL's standard root fields
  (`contact_id`, `message.body`) directly.

**Workflow 2 — your own approval replies.** Trigger: **Customer replied**,
filtered to `Has tag: internal-approver`. Add a **Webhook** action:
- URL: `https://<your-deployed-host>/webhooks/ghl-approval`
- Method: POST
- Header: `x-webhook-secret: <same value as GHL_WEBHOOK_SECRET>`

Publish both workflows.

## 7. Deploy

Railway (recommended — one command):

```bash
npm install -g @railway/cli
railway login
railway init
railway up
```

Then set your `.env` values as Railway variables (Settings > Variables, or
`railway variables set KEY=value` for each one), and set `PORT=3000` as an
explicit variable so the domain's target port matches. Generate a domain
under Settings > Networking, and use that URL for the workflow webhooks in
step 6.

## 8. Test it

```bash
npm run verify:ghl
```

This sanity-checks your token/location by listing one contact. Then text your
own number (the one enrolled in a drip campaign or tagged appropriately) to
trigger a real end-to-end test, and confirm you get a reply.

---

## How it behaves (for reference)

- **Classification**: every lead reply gets sorted into `logistics`
  (pure scheduling — auto-sent), `needs_approval` (price/coverage/health/
  carrier — held, texted to you for YES/NO/EDIT), or `no_reply` (lead just
  acknowledged something already said — nothing sent, prevents the bot
  repeating itself).
- **Carrier mentions and coverage objections** run a scripted "act
  confused → probe for a health reason → reframe as wrong rate class"
  sequence instead of a neutral handoff — see the checklist in section 0,
  this is the part most worth reading before you turn it on. Still always
  held for your approval, never auto-sent.
- **Booking negotiation** leans on scarcity (you're busy, the lead's been
  waiting) and closes with a message asking the lead to keep their phone
  nearby and text ahead if they need to reschedule — aimed at reducing
  no-shows. Appointments more than 3 days out get pushed back on instead of
  accepted.
- **Appointments**: the bot does not book on your calendar directly — GHL's
  public API tags bot-created appointments as third-party, which causes
  duplicate confirmation texts to the lead and breaks Google Calendar sync
  (a GHL platform limitation, not fixable from here). Instead it texts you
  the confirmed time (converted to your timezone) so you book it yourself via
  the normal "Add Appointment" button.
- **Pausing per contact**: the bot automatically backs off a contact (tags
  them `bot-paused`) if they already have an active GHL calendar appointment,
  or if a real person's message shows up in their thread that the bot didn't
  send (you replying manually — a native GHL workflow sending its own text
  does NOT count as a takeover and won't pause the bot). Paused contacts
  still get drafted-and-held for your review on every new message, not
  silence. Remove the tag in GHL to resume normal auto-handling.
- **Daily review** (runs nightly, business-timezone 9pm by default — see
  `src/schedule/dailyReview.ts`): scans the last 24h for dead threads (bot
  sent something, lead never replied or hard-objected) and for times you
  personally rescued a paused/stuck thread, texts you a digest, and drafts a
  fresh follow-up for every silent (non-objection) dead-end, held for your
  approval. Trigger it manually any time via `POST /internal/run-daily-review`
  (needs the `x-internal-secret` header set to `INTERNAL_JOB_SECRET`).
- **Daily SMS limits**: GHL/Twilio numbers have a daily send cap that steps up
  gradually over consecutive days as the number builds trust (this is normal
  carrier throughput scaling, not a bug) — expect roughly 250-500/day at
  first. High opt-out rates and dead/invalid numbers on your lead lists slow
  that climb down, so list quality matters for more than just this bot.
- **Anthropic usage limits**: if your Anthropic account hits its own usage
  cap, every draft call fails with a 400 and — this is the important part —
  the pipeline does NOT retry, it marks the event processed and moves on. A
  lead who texts in during an outage gets silently skipped with no alert
  unless you're watching the logs. Keep an eye on your usage limit in
  console.anthropic.com, especially early on.
